package com.bjpowernode.drp;

/**
 * ϵͳ�����ĳ���
 * @author Administrator
 *
 */
public class Constants {

	public static final String NO = "N";
	
	public static final String YES = "Y";
	
	public static final String MODIFY = "modify";
	
	public static final String ADD = "add";
	
	public static final String DEL = "del";
	
	public static final String command = "command";
}
