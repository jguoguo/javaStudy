package com.bjpowernode.drp.domain;

/**
 * ���ϵ�λ
 * @author Administrator
 *
 */
public class ItemUnit extends AbstractDataDict{

}
