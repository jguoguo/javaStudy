package com.bjpowernode.drp.domain;

/**
 * �������
 * @author Administrator
 *
 */
public class ItemCategory extends AbstractDataDict{

}
